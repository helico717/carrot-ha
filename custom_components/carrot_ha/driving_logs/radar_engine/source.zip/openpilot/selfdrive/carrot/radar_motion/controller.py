#!/usr/bin/env python3
"""Lead-role controller for the independent physical dPath RadarD."""

from __future__ import annotations

import math
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

from openpilot.selfdrive.carrot.radar_motion.lead_dynamics import LEAD_ACCEL_TAU_S, LeadAccelTau
from openpilot.selfdrive.carrot.radar_motion.lead_selection import (
  DPathLeadCandidate,
  DPathStationaryPrimaryHandoffTracker,
  DPathStationaryShadowTracker,
  DPathLeadTwoTracker,
  cutin_can_compete_with_primary,
  lead_duplicates_primary,
)
from openpilot.selfdrive.carrot.radar_motion.predictor import (
  RadarMotionPredictor,
  _scoped_motion_points,
  _visible_scoped_motion_points,
  project_to_model_path,
)
from openpilot.selfdrive.carrot.radar_motion.primary import (
  FrontRadarKinematicAssociator,
  RadarPointSnapshot,
  STATIONARY_MAX_ABS_VLEAD_MPS,
  STATIONARY_FRONT_ANCHOR_MAX_AGE_S,
  STATIONARY_FRONT_ANCHOR_MAX_SPEED_JUMP_MPS,
  STATIONARY_FRONT_POSITION_LOCK_MIN_TRACK_STATE,
  STATIONARY_FRONT_RANGE_MAX_DPATH_M,
  STATIONARY_FRONT_RANGE_MAX_ERROR_M,
  STATIONARY_FRONT_RANGE_MAX_FRACTION,
  STATIONARY_FRONT_RANGE_MAX_YREL_ERROR_M,
  STATIONARY_FRONT_RANGE_XSTD_SIGMA,
  STATIONARY_VISION_CROSS_SOURCE_MAX_DREL_M,
  STATIONARY_VISION_CROSS_SOURCE_MAX_VLEAD_MPS,
  VISION_RADAR_MAX_DISTANCE_ERROR_M,
  VISION_LEAD_MIN_PROB,
  VisionLead,
  VisionRadarMatcher,
  lead_from_vision,
  lead_from_radar_point,
  match_dpath_primary_lead,
  prefer_front_radar_kinematics,
  select_primary_radar_points,
  snapshot_live_radar_points,
  snapshot_radar_points,
  stationary_vision_support_probability,
  unconditional_scc_match,
  vision_lead_from_model,
  vision_only_lead_allowed,
)
from openpilot.selfdrive.carrot.radar_motion.trajectory_cutin import (
  TrajectoryCutInDetector,
)
from openpilot.selfdrive.carrot.radar_motion.trajectory_cutout import TrajectoryCutOutTracker


# modelV2 is polled at 20 Hz while liveTracks may arrive just before or after
# the camera exposure represented by timestampEof. This bounds publication
# skew only. A vehicle's declared sensor measurement delay can legitimately be
# larger (VW MEB uses 0.8 s) and is applied below as a position projection.
RADAR_MOTION_MAX_TIME_SKEW_S = 0.15
# The 0x235/0x180/0x430 object stream is one radar cycle old when emitted.
# Keep this separate from the vehicle's front-radar delay.
CORNER_RADAR_MEASUREMENT_DELAY_S = 0.05
STATIONARY_SHADOW_CORNER_MIN_DREL_GATE_M = 7.0
STATIONARY_SHADOW_CORNER_MAX_DREL_GATE_M = 12.0
STATIONARY_SHADOW_CORNER_DREL_GATE_FRACTION = 0.15
STATIONARY_SHADOW_CORNER_MAX_DPATH_M = 1.25
STATIONARY_SHADOW_CORNER_MAX_DPATH_DELTA_M = 1.25
STATIONARY_SHADOW_CORNER_MAX_ABS_VLEAD_MPS = 3.0
STATIONARY_SHADOW_CORNER_MAX_VLEAD_DELTA_MPS = 3.0
SCC_LEAD_TWO_CONFIRMATION_S = 0.15
SCC_LEAD_TWO_SUPPORT_HOLD_S = 0.10
SCC_LEAD_TWO_MAX_DREL_M = 150.0
SCC_LEAD_TWO_MAX_VLEAD_MPS = 5.0
SCC_LEAD_TWO_MAX_POSITION_ERROR_M = 3.0
SCC_LEAD_TWO_MAX_SPEED_JUMP_MPS = 2.0
SCC_PHYSICAL_MATCH_MIN_DREL_M = 4.0
SCC_PHYSICAL_MATCH_DREL_FRACTION = 0.05
SCC_PHYSICAL_MATCH_MAX_DREL_M = 8.0
SCC_PHYSICAL_MATCH_MAX_VLEAD_DELTA_MPS = 3.0
SCC_PHYSICAL_MATCH_MAX_ABS_DPATH_M = 2.2
SCC_CORNER_MATCH_MAX_YREL_DELTA_M = 1.25
SCC_PRIMARY_DUPLICATE_MAX_DREL_DELTA_M = 5.0
RADAR_VISION_FALLBACK_MAX_ABS_DPATH_M = 1.0
RADAR_VISION_FALLBACK_MIN_PROBABILITY = 0.40
RADAR_MATCH_MAX_FARTHER_THAN_VISION_M = 8.0
MOVING_FRONT_RANGE_XSTD_SIGMA = 1.5
MOVING_FRONT_RANGE_MAX_DISTANCE_FRACTION = 0.15
MOVING_FRONT_RANGE_MAX_GAP_S = 0.15
MOVING_FRONT_RANGE_MAX_POSITION_ERROR_M = 2.5
MOVING_FRONT_RANGE_MAX_LATERAL_ERROR_M = 0.75
MOVING_FRONT_RANGE_MAX_SPEED_JUMP_MPS = 3.0
CORROBORATED_STATIONARY_VISION_RANGE_MISMATCH_HOLD_S = 0.15
SCC_PRIMARY_DUPLICATE_MAX_VLEAD_DELTA_MPS = 3.0
SCC_PRIMARY_CLOSER_MARGIN_M = 1.0
CROSS_SENSOR_CLOSE_CUTIN_MIN_DREL_M = 2.0
CROSS_SENSOR_CLOSE_CUTIN_MAX_DREL_M = 12.0
CROSS_SENSOR_CLOSE_CUTIN_MAX_ABS_DPATH_M = 3.0
CROSS_SENSOR_CLOSE_CUTIN_MIN_VLEAD_MPS = 0.5
# EnableRadarTracks 3 adopts the OEM SCC object with its lateral position zeroed. When the
# front/corner radar tracks of that same body put it clearly beside the path, it is an
# adjacent-lane car (2026-09-24 queue, 2026-10-06 lane change phantoms): do not adopt it.
# Close-range radar lateral can read 1.3-2.0 m for a car straight ahead, so "near" is 2.0 m.
FORCED_SCC_NEAR_PATH_M = 2.0
FORCED_SCC_BESIDE_PATH_M = 2.5
FORCED_SCC_VISION_MIN_PROB = 0.5
# During a lane change the old lane can still hold a stopped car the path has already left.
FORCED_SCC_LANE_CHANGE_KEEP_VLEAD_MPS = 5.0
FORCED_SCC_REJECT_HOLD_S = 1.0
LANE_CHANGE_ACTIVE_STATES = frozenset(("preLaneChange", "laneChangeStarting", "laneChangeFinishing"))


def _is_corner(point: RadarPointSnapshot) -> bool:
  return point.source.startswith("corner")


def _lane_change_active(model: Any) -> bool:
  meta = getattr(model, "meta", None)
  return str(getattr(meta, "laneChangeState", "off")) in LANE_CHANGE_ACTIVE_STATES


def _forced_scc_lateral_evidence(
  scc: RadarPointSnapshot,
  points: tuple[RadarPointSnapshot, ...],
  path: tuple[tuple[float, float], ...],
  vision: VisionLead | None,
  model: Any,
) -> tuple[bool, bool]:
  """(beside_path, in_lane) for the SCC body that mode 3 would adopt unconditionally."""
  if _lane_change_active(model) and scc.v_lead < FORCED_SCC_LANE_CHANGE_KEEP_VLEAD_MPS:
    return False, True
  if (
    vision is not None
    and vision.probability >= FORCED_SCC_VISION_MIN_PROB
    and abs(vision.d_rel - scc.d_rel) <= max(
      SCC_PHYSICAL_MATCH_MIN_DREL_M, scc.d_rel * SCC_PHYSICAL_MATCH_DREL_FRACTION,
    )
    and abs(vision.y_rel) <= FORCED_SCC_NEAR_PATH_M
  ):
    return False, True
  supports = [
    support for support in (
      _scc_physical_support(
        scc, (point for point in points if point.source == "frontRadar"), path, require_path=False,
      ),
      _scc_physical_support(
        scc, (point for point in points if _is_corner(point)), path, require_path=False,
      ),
    )
    if support is not None
  ]
  if not supports:
    return False, False  # no physical match: SCC may be the only sensor on this car
  d_paths = [abs(project_to_model_path(path, point.d_rel, point.y_rel).d_path) for point in supports]
  # A noisy model path alone must not push a car out: the raw lateral has to agree.
  if min(d_paths) < FORCED_SCC_NEAR_PATH_M or min(abs(point.y_rel) for point in supports) < FORCED_SCC_NEAR_PATH_M:
    return False, True
  # Front and corner on different bodies: reject only if both are clearly beside the path.
  agree = len(supports) < 2 or abs(supports[0].y_rel - supports[1].y_rel) <= SCC_CORNER_MATCH_MAX_YREL_DELTA_M
  beside = max(d_paths) >= FORCED_SCC_BESIDE_PATH_M and (agree or min(d_paths) >= FORCED_SCC_BESIDE_PATH_M)
  return beside, False


def _model_path(model: Any) -> tuple[tuple[float, float], ...]:
  position = getattr(model, "position", None)
  if position is None:
    return ()
  return tuple(
    (float(x), float(y))
    for x, y in zip(position.x, position.y, strict=False)
    if math.isfinite(float(x)) and math.isfinite(float(y))
  )


def _model_ego_speed(model: Any, fallback: float) -> float:
  velocity = getattr(model, "velocity", None)
  values = getattr(velocity, "x", ()) if velocity is not None else ()
  try:
    value = float(values[0])
  except (IndexError, TypeError, ValueError):
    return float(fallback)
  return value if math.isfinite(value) else float(fallback)


def stationary_shadow_corner_supported(
  front: RadarPointSnapshot,
  points: Iterable[RadarPointSnapshot],
  path: tuple[tuple[float, float], ...],
) -> bool:
  """Require an independent slow corner return for a stopped front shadow."""
  front_d_path = project_to_model_path(
    path, front.d_rel, front.y_rel,
  ).d_path
  d_rel_gate = min(
    STATIONARY_SHADOW_CORNER_MAX_DREL_GATE_M,
    max(
      STATIONARY_SHADOW_CORNER_MIN_DREL_GATE_M,
      front.d_rel * STATIONARY_SHADOW_CORNER_DREL_GATE_FRACTION,
    ),
  )
  for corner in points:
    if (
      not corner.measured
      or not _is_corner(corner)
      or abs(corner.v_lead)
      > STATIONARY_SHADOW_CORNER_MAX_ABS_VLEAD_MPS
      or abs(front.d_rel - corner.d_rel) > d_rel_gate
      or abs(front.v_lead - corner.v_lead)
      > STATIONARY_SHADOW_CORNER_MAX_VLEAD_DELTA_MPS
    ):
      continue
    corner_d_path = project_to_model_path(
      path, corner.d_rel, corner.y_rel,
    ).d_path
    if (
      abs(corner_d_path) <= STATIONARY_SHADOW_CORNER_MAX_DPATH_M
      and abs(front_d_path - corner_d_path)
      <= STATIONARY_SHADOW_CORNER_MAX_DPATH_DELTA_M
    ):
      return True
  return False


def _scc_physical_support(
  scc: RadarPointSnapshot,
  points: Iterable[RadarPointSnapshot],
  path: tuple[tuple[float, float], ...],
  *,
  require_path: bool = True,
) -> RadarPointSnapshot | None:
  """Prefer an in-path physical return that corroborates the OEM SCC lead."""
  d_rel_gate = min(
    SCC_PHYSICAL_MATCH_MAX_DREL_M,
    max(
      SCC_PHYSICAL_MATCH_MIN_DREL_M,
      scc.d_rel * SCC_PHYSICAL_MATCH_DREL_FRACTION,
    ),
  )
  supported = []
  for point in points:
    if (
      not point.measured
      or point.source == "scc"
      or not (
        point.source == "frontRadar" or _is_corner(point)
      )
      or abs(point.d_rel - scc.d_rel) > d_rel_gate
      or abs(point.v_lead - scc.v_lead)
      > SCC_PHYSICAL_MATCH_MAX_VLEAD_DELTA_MPS
    ):
      continue
    projection = project_to_model_path(
      path, point.d_rel, point.y_rel,
    )
    if require_path and abs(projection.d_path) > SCC_PHYSICAL_MATCH_MAX_ABS_DPATH_M:
      continue
    supported.append((
      0 if point.source == "frontRadar" else 1,
      abs(point.d_rel - scc.d_rel),
      abs(point.v_lead - scc.v_lead),
      point,
    ))
  return min(
    supported,
    key=lambda candidate: candidate[:3],
    default=(0, 0.0, 0.0, None),
  )[-1]


def _scc_lead_two_independently_supported(
  scc: RadarPointSnapshot,
  physical: RadarPointSnapshot | None,
  points: Iterable[RadarPointSnapshot],
  path: tuple[tuple[float, float], ...],
  vision: VisionLead | None,
  primary: dict[str, Any] | None,
) -> bool:
  # The OEM SCC object and the front object list come from the same radar.
  # Agreement between them also occurs for bridge joints and road reflections;
  # it identifies a return, but is not independent evidence of a vehicle.
  point_values = tuple(points)
  front = (
    physical if physical is not None and physical.source == "frontRadar"
    else _scc_physical_support(
      scc, (point for point in point_values if point.source == "frontRadar"),
      path, require_path=False,
    )
  )
  # Associate sensors in physical coordinates. Long-range model path wobble
  # must not erase agreement between the same front/corner body. Physical
  # lead output still uses the original path gate; SCC owns its backup role.
  corner = _scc_physical_support(
    scc,
    (
      point for point in point_values if _is_corner(point)
      and (
        front is None
        or (
          abs(front.d_rel - point.d_rel) <= STATIONARY_VISION_CROSS_SOURCE_MAX_DREL_M
          and abs(front.y_rel - point.y_rel) <= SCC_CORNER_MATCH_MAX_YREL_DELTA_M
          and abs(front.v_lead - point.v_lead) <= STATIONARY_VISION_CROSS_SOURCE_MAX_VLEAD_MPS
        )
      )
    ),
    path,
    require_path=front is None,
  )
  if corner is not None:
    return True

  point = physical or scc
  if VisionRadarMatcher._stationary_vision_base_cost(vision, point) is None:
    return False
  # A camera lead already associated with a distinct moving front object
  # cannot also authenticate a nearer stationary SCC return.
  if (
    primary is not None
    and primary.get("status") and primary.get("radar")
    and float(primary.get("modelProb", 0.0)) >= VISION_LEAD_MIN_PROB
    and (
      abs(point.d_rel - float(primary["dRel"])) > SCC_PRIMARY_DUPLICATE_MAX_DREL_DELTA_M
      or abs(point.v_lead - float(primary["vLead"])) > SCC_PRIMARY_DUPLICATE_MAX_VLEAD_DELTA_MPS
    )
  ):
    return False
  return True


class DPathSccLeadTwoTracker:
  """Confirm a low-speed SCC backup with independent object evidence."""

  def __init__(self) -> None:
    self._since_s: float | None = None
    self._last_time_s: float | None = None
    self._last_point: RadarPointSnapshot | None = None
    self._last_support_s: float | None = None
    self._confirmed = False

  def reset(self) -> None:
    self._since_s = None
    self._last_time_s = None
    self._last_point = None
    self._last_support_s = None
    self._confirmed = False

  def _continuous(
    self,
    time_s: float,
    point: RadarPointSnapshot,
  ) -> bool:
    if self._last_time_s is None or self._last_point is None:
      return True
    dt = float(time_s) - self._last_time_s
    if dt < 0.0 or dt > RADAR_MOTION_MAX_TIME_SKEW_S:
      return False
    predicted_d_rel = self._last_point.d_rel + self._last_point.v_rel * dt
    return (
      abs(point.d_rel - predicted_d_rel)
      <= SCC_LEAD_TWO_MAX_POSITION_ERROR_M
      and abs(point.v_lead - self._last_point.v_lead)
      <= SCC_LEAD_TWO_MAX_SPEED_JUMP_MPS
    )

  def update(
    self,
    time_s: float,
    point: RadarPointSnapshot | None,
    *,
    independently_supported: bool,
  ) -> RadarPointSnapshot | None:
    if point is None:
      self.reset()
      return None
    if not self._continuous(time_s, point):
      self.reset()
    if independently_supported:
      self._last_support_s = float(time_s)
    elif (
      not self._confirmed
      or self._last_support_s is None
      or not 0.0 <= float(time_s) - self._last_support_s <= SCC_LEAD_TWO_SUPPORT_HOLD_S
    ):
      self.reset()
      return None
    if self._since_s is None:
      self._since_s = float(time_s)
    self._last_time_s = float(time_s)
    self._last_point = point
    if (
      self._since_s is None
      or float(time_s) - self._since_s < SCC_LEAD_TWO_CONFIRMATION_S
    ):
      return None
    self._confirmed = True
    return point


def _scc_lead_two_can_compete(
  lead: dict[str, Any],
  primary: dict[str, Any] | None,
) -> bool:
  if primary is None or not primary.get("status"):
    return True
  if lead_duplicates_primary(lead, primary):
    return False
  distance_delta = abs(
    float(lead.get("dRel", 0.0))
    - float(primary.get("dRel", 0.0))
  )
  speed_delta = abs(
    float(lead.get("vLead", 0.0))
    - float(primary.get("vLead", 0.0))
  )
  if (
    distance_delta <= SCC_PRIMARY_DUPLICATE_MAX_DREL_DELTA_M
    and speed_delta <= SCC_PRIMARY_DUPLICATE_MAX_VLEAD_DELTA_MPS
  ):
    return False
  return (
    float(lead.get("dRel", math.inf)) + SCC_PRIMARY_CLOSER_MARGIN_M
    < float(primary.get("dRel", math.inf))
  )


def _central_vision_fallback_allowed(
  vision: Any,
  path: tuple[tuple[float, float], ...],
) -> bool:
  return bool(
    vision is not None
    and vision.probability >= RADAR_VISION_FALLBACK_MIN_PROBABILITY
    and abs(
      project_to_model_path(path, vision.d_rel, vision.y_rel).d_path
    ) <= RADAR_VISION_FALLBACK_MAX_ABS_DPATH_M
  )


def _radar_match_is_dangerously_farther_than_vision(
  match: Any,
  vision: Any,
  path: tuple[tuple[float, float], ...],
  max_farther_than_vision_m: float = RADAR_MATCH_MAX_FARTHER_THAN_VISION_M,
) -> bool:
  """Reject a permissive radar match that can hide a much nearer visual car."""
  return bool(
    match is not None
    and _central_vision_fallback_allowed(vision, path)
    and match.point.d_rel - vision.d_rel
    > max_farther_than_vision_m
  )


@dataclass(frozen=True)
class DPathRadarOutput:
  lead_one: dict[str, Any] | None
  lead_two: dict[str, Any] | None
  lead_left: dict[str, Any] | None
  lead_right: dict[str, Any] | None
  leads_left: tuple[dict[str, Any], ...]
  leads_center: tuple[dict[str, Any], ...]
  leads_right: tuple[dict[str, Any], ...]
  leads_cutin: tuple[dict[str, Any], ...]
  leads_left2: tuple[dict[str, Any], ...]
  leads_right2: tuple[dict[str, Any], ...]
  lead_cutin_risk: dict[str, Any] | None


class RadarLeadDynamics:
  """Keep acceleration persistence with the physical kinematics identity."""

  def __init__(self) -> None:
    self._a_lead_tau: dict[tuple[str, int], LeadAccelTau] = {}

  @staticmethod
  def _identity(point: RadarPointSnapshot) -> tuple[str, int]:
    if (
      point.kinematics_source is not None
      and point.kinematics_track_id is not None
    ):
      return point.kinematics_source, point.kinematics_track_id
    return point.source, point.track_id

  def reset(self) -> None:
    self._a_lead_tau.clear()

  def update(
    self,
    points: tuple[RadarPointSnapshot, ...],
    sample_time_s: float,
  ) -> None:
    active: set[tuple[str, int]] = set()
    for point in points:
      identity = point.source, point.track_id
      active.add(identity)
      if identity not in self._a_lead_tau:
        self._a_lead_tau[identity] = LeadAccelTau()
      self._a_lead_tau[identity].update(point.a_lead, point.j_lead, sample_time_s, measured=point.measured)

    for identity in tuple(self._a_lead_tau):
      if identity not in active:
        del self._a_lead_tau[identity]

  def a_lead_tau(self, point: RadarPointSnapshot) -> float:
    state = self._a_lead_tau.get(self._identity(point))
    return state.tau if state is not None else LEAD_ACCEL_TAU_S


class DPathRadarController:
  """Calculate leadOne, then current-path and dPath CUT-IN leadTwo."""

  def __init__(
    self,
    prefer_corner_radar: bool = False,
    enable_radar_tracks: int = 1,
    cut_in_sensitivity: int = 3,
    front_radar_measurement_delay_s: float = 0.0,
    corner_radar_measurement_delay_s: float = CORNER_RADAR_MEASUREMENT_DELAY_S,
    production_live_tracks: bool = False,
  ) -> None:
    self.primary_matcher = VisionRadarMatcher()
    self.scc_primary_fallback_matcher = VisionRadarMatcher()
    self.forced_scc_rejected_s: float | None = None  # last frame mode 3 refused a beside-path SCC body
    self._forced_scc_previous: tuple[float, RadarPointSnapshot] | None = None
    self.enable_radar_tracks = int(enable_radar_tracks)
    self.front_radar_measurement_delay_s = max(
      0.0, float(front_radar_measurement_delay_s),
    )
    self.corner_radar_measurement_delay_s = max(
      0.0, float(corner_radar_measurement_delay_s),
    )
    self.production_live_tracks = bool(production_live_tracks)
    self.motion_sensor = "corner" if prefer_corner_radar else "front"
    self.cut_in_sensitivity = max(0, min(5, int(cut_in_sensitivity)))
    self._reset_motion_pipeline()
    self.primary_cut_out_predictor = RadarMotionPredictor(cut_out_only=True)
    self.trajectory_cutout = TrajectoryCutOutTracker()
    self.front_kinematic_associator = FrontRadarKinematicAssociator()
    self.lead_two_tracker = DPathLeadTwoTracker()
    self.stationary_shadow_tracker = DPathStationaryShadowTracker()
    self.stationary_primary_handoff_tracker = (
      DPathStationaryPrimaryHandoffTracker()
    )
    self.scc_lead_two_tracker = DPathSccLeadTwoTracker()
    self.lead_dynamics = RadarLeadDynamics()
    self._stationary_vision_range_mismatch_identity: (
      tuple[str, int] | None
    ) = None
    self._stationary_vision_range_mismatch_since_s: float | None = None
    self._moving_range_last_point: RadarPointSnapshot | None = None
    self._moving_range_last_time_s: float | None = None
    self._stationary_range_last_point: RadarPointSnapshot | None = None
    self._stationary_range_last_time_s: float | None = None
    self._stationary_range_anchor_time_s: float | None = None

  def _reset_stationary_range_history(self) -> None:
    self._stationary_range_last_point = None
    self._stationary_range_last_time_s = None
    self._stationary_range_anchor_time_s = None

  def _stationary_front_range_limit(self, match: Any, vision: Any, time_s: float) -> tuple[float, float | None]:
    limit = RADAR_MATCH_MAX_FARTHER_THAN_VISION_M
    if match is None or vision is None or not math.isfinite(time_s):
      return limit, None
    point = match.point
    if (
      point.source != "frontRadar" or not point.measured
      or point.radar_track_state < STATIONARY_FRONT_POSITION_LOCK_MIN_TRACK_STATE
      or abs(point.v_lead) > STATIONARY_MAX_ABS_VLEAD_MPS
      or (point.source, point.track_id) != self.primary_matcher.stationary_identity
      or abs(match.d_path) > STATIONARY_FRONT_RANGE_MAX_DPATH_M
      or vision.probability < RADAR_VISION_FALLBACK_MIN_PROBABILITY
      or abs(point.y_rel - vision.y_rel) > STATIONARY_FRONT_RANGE_MAX_YREL_ERROR_M
    ):
      return limit, None
    anchor_time_s = None
    if abs(point.d_rel - vision.d_rel) <= limit:
      anchor_time_s = time_s
    elif (
      self._stationary_range_last_point is not None
      and self._stationary_range_last_time_s is not None
      and self._stationary_range_anchor_time_s is not None
      and 0.0 < time_s - self._stationary_range_last_time_s <= RADAR_MOTION_MAX_TIME_SKEW_S
      and time_s - self._stationary_range_anchor_time_s <= STATIONARY_FRONT_ANCHOR_MAX_AGE_S
      and VisionRadarMatcher._stationary_position_continuous(
        self._stationary_range_last_point, self._stationary_range_last_time_s, point, time_s,
      )
      and abs(point.v_lead - self._stationary_range_last_point.v_lead) <= STATIONARY_FRONT_ANCHOR_MAX_SPEED_JUMP_MPS
    ):
      anchor_time_s = self._stationary_range_anchor_time_s
    if anchor_time_s is None:
      anchor_time_s = self.primary_matcher.stationary_front_anchor_time(point, time_s)
    if anchor_time_s is not None and math.isfinite(vision.x_std) and vision.x_std > 0.0:
      limit = max(limit, min(
        STATIONARY_FRONT_RANGE_MAX_ERROR_M,
        STATIONARY_FRONT_RANGE_MAX_FRACTION * vision.d_rel,
        STATIONARY_FRONT_RANGE_XSTD_SIGMA * vision.x_std,
      ))
    return limit, anchor_time_s

  def _reset_motion_pipeline(self) -> None:
    self.trajectory_cutin = TrajectoryCutInDetector(self.cut_in_sensitivity)
    self._same_row_suppressed_until: dict[tuple[str, int, int], float] = {}

  def _reset_stationary_vision_range_mismatch(self) -> None:
    self._stationary_vision_range_mismatch_identity = None
    self._stationary_vision_range_mismatch_since_s = None

  def _reject_farther_radar_match(
    self,
    match: Any,
    vision: Any,
    path: tuple[tuple[float, float], ...],
    time_s: float,
  ) -> bool:
    confirmed = self.primary_matcher.closing_range_match
    if (match is not None and confirmed is not None
        and (match.point.source, match.point.track_id) == (confirmed.point.source, confirmed.point.track_id)):
      # This exact current frame passed range/velocity continuity, path and
      # stopped-equivalent urgency checks; do not reapply a distance-only veto.
      self._moving_range_last_point = match.point
      self._moving_range_last_time_s = time_s
      self._reset_stationary_vision_range_mismatch()
      return False
    # Only an accepted, continuously measured moving front may use vision's
    # range uncertainty. A fresh ID, a position jump, or a missed match must
    # qualify again under the normal nearer-car guard.
    point = match.point if match is not None else None
    moving_front = bool(
      point is not None
      and point.source == "frontRadar"
      and point.measured
      and point.v_lead > STATIONARY_MAX_ABS_VLEAD_MPS
      and _central_vision_fallback_allowed(vision, path)
      and vision.velocity > STATIONARY_MAX_ABS_VLEAD_MPS
      and abs(match.d_path) <= RADAR_VISION_FALLBACK_MAX_ABS_DPATH_M
    )
    previous = self._moving_range_last_point
    previous_time_s = self._moving_range_last_time_s
    range_limit = RADAR_MATCH_MAX_FARTHER_THAN_VISION_M
    if moving_front and previous is not None and previous_time_s is not None:
      dt = time_s - previous_time_s
      if (
        (point.source, point.track_id) == (previous.source, previous.track_id)
        and 0.0 < dt <= MOVING_FRONT_RANGE_MAX_GAP_S
        and abs(point.d_rel - (previous.d_rel + previous.v_rel * dt))
        <= MOVING_FRONT_RANGE_MAX_POSITION_ERROR_M
        and abs(point.y_rel - (previous.y_rel + previous.yv_rel * dt))
        <= MOVING_FRONT_RANGE_MAX_LATERAL_ERROR_M
        and abs(point.v_lead - previous.v_lead)
        <= MOVING_FRONT_RANGE_MAX_SPEED_JUMP_MPS
        and math.isfinite(vision.x_std)
        and vision.x_std > 0.0
      ):
        range_limit = max(
          range_limit,
          min(
            VISION_RADAR_MAX_DISTANCE_ERROR_M,
            MOVING_FRONT_RANGE_MAX_DISTANCE_FRACTION * vision.d_rel,
            MOVING_FRONT_RANGE_XSTD_SIGMA * vision.x_std,
          ),
        )
    stationary_limit, stationary_anchor_time_s = self._stationary_front_range_limit(match, vision, time_s)
    range_limit = max(range_limit, stationary_limit)
    self._reset_stationary_range_history()
    self._moving_range_last_point = None
    self._moving_range_last_time_s = None
    if not _radar_match_is_dangerously_farther_than_vision(
      match, vision, path, range_limit,
    ):
      if moving_front:
        self._moving_range_last_point = point
        self._moving_range_last_time_s = time_s
      if stationary_anchor_time_s is not None:
        self._stationary_range_last_point = point
        self._stationary_range_last_time_s = time_s
        self._stationary_range_anchor_time_s = stationary_anchor_time_s
      self._reset_stationary_vision_range_mismatch()
      return False

    identity = (match.point.source, match.point.track_id)
    corroborated_stationary = bool(
      identity == self.primary_matcher.stationary_identity
      and self.primary_matcher.stationary_corner_supported
      and match.point.source == "frontRadar"
      and match.point.measured
      and abs(match.point.v_lead) <= STATIONARY_MAX_ABS_VLEAD_MPS
    )
    if not corroborated_stationary:
      self._reset_stationary_vision_range_mismatch()
      return True
    if identity != self._stationary_vision_range_mismatch_identity:
      self._stationary_vision_range_mismatch_identity = identity
      self._stationary_vision_range_mismatch_since_s = time_s
      return False
    return bool(
      self._stationary_vision_range_mismatch_since_s is not None
      and time_s - self._stationary_vision_range_mismatch_since_s
      >= CORROBORATED_STATIONARY_VISION_RANGE_MISMATCH_HOLD_S
    )

  def _reject_forced_scc(
    self,
    scc: RadarPointSnapshot,
    points: tuple[RadarPointSnapshot, ...],
    path: tuple[tuple[float, float], ...],
    vision: VisionLead | None,
    model: Any,
    time_s: float,
  ) -> bool:
    """Mode 3: refuse a beside-path SCC body; hold the refusal briefly through support dropouts."""
    # SCC commonly reuses track ID 0 for different cars. A distance/speed jump
    # must not transfer a previous adjacent car's refusal to the new lead.
    previous = self._forced_scc_previous
    continuous = False
    if previous is not None:
      previous_s, point = previous
      dt = time_s - previous_s
      continuous = (
        0.0 <= dt <= FORCED_SCC_REJECT_HOLD_S
        and (scc.source, scc.track_id) == (point.source, point.track_id)
        and abs(scc.d_rel - (point.d_rel + point.v_rel * dt)) <= 2.0
        and abs(scc.v_rel - point.v_rel) <= 3.0
      )
    if not continuous:
      self.forced_scc_rejected_s = None
    self._forced_scc_previous = (time_s, scc)
    beside, in_lane = _forced_scc_lateral_evidence(scc, points, path, vision, model)
    if in_lane:
      self.forced_scc_rejected_s = None
      return False
    if beside:
      self.forced_scc_rejected_s = time_s
      return True
    return (
      self.forced_scc_rejected_s is not None
      and 0.0 <= time_s - self.forced_scc_rejected_s <= FORCED_SCC_REJECT_HOLD_S
    )

  def _points_at_model_time(
    self,
    radar_points: Any,
    v_ego: float,
    radar_to_model_time_s: float,
  ) -> tuple[RadarPointSnapshot, ...]:
    publication_skew_s = float(radar_to_model_time_s)
    if (
      not math.isfinite(publication_skew_s)
      or abs(publication_skew_s) > RADAR_MOTION_MAX_TIME_SKEW_S
    ):
      return ()

    aligned: list[RadarPointSnapshot] = []
    batch: list[Any] = []
    batch_time_delta_s: float | None = None
    snapshotter = (
      snapshot_live_radar_points
      if self.production_live_tracks
      else snapshot_radar_points
    )
    for point in radar_points:
      source = (
        str(point.radarSource)
        if self.production_live_tracks
        else str(getattr(point, "radarSource", getattr(point, "source", "")))
      )
      measurement_delay_s = (
        self.corner_radar_measurement_delay_s
        if source.rsplit(".", 1)[-1].startswith("corner")
        else self.front_radar_measurement_delay_s
      )
      time_delta_s = publication_skew_s + measurement_delay_s
      if (
        batch
        and batch_time_delta_s is not None
        and time_delta_s != batch_time_delta_s
      ):
        aligned.extend(snapshotter(
          batch, v_ego, batch_time_delta_s,
        ))
        batch.clear()
      batch.append(point)
      batch_time_delta_s = time_delta_s
    if batch and batch_time_delta_s is not None:
      aligned.extend(snapshotter(
        batch, v_ego, batch_time_delta_s,
      ))
    return tuple(aligned)

  def _select_motion_points(
    self,
    points: tuple[RadarPointSnapshot, ...],
  ) -> tuple[RadarPointSnapshot, ...]:
    corner_points = tuple(point for point in points if _is_corner(point))
    if self.motion_sensor == "front" and corner_points:
      # Sensor selection is latched. A temporary corner dropout never causes a
      # frame-by-frame fallback to front radar.
      self.motion_sensor = "corner"
      self._reset_motion_pipeline()
      self.lead_two_tracker.reset()
      self.stationary_shadow_tracker.reset()
      self.stationary_primary_handoff_tracker.reset()
      self.scc_lead_two_tracker.reset()
    if self.motion_sensor == "corner":
      return corner_points
    return tuple(point for point in points if point.source == "frontRadar")

  @staticmethod
  def _pick_side(
    leads: tuple[dict[str, Any], ...],
  ) -> dict[str, Any] | None:
    return min(
      (
        lead for lead in leads
        if lead["dRel"] > 5.0 and abs(lead["dPath"]) < 3.5
      ),
      key=lambda lead: lead["dRel"],
      default=None,
    )

  @staticmethod
  def _pick_two(
    leads: tuple[dict[str, Any], ...],
  ) -> tuple[dict[str, Any], ...]:
    usable = tuple(
      lead for lead in leads
      if (
        lead["vLead"] > 2.0
        and abs(lead["dPath"]) < 4.2
        and lead["dRel"] > 2.0
      )
    )
    if not usable:
      return ()
    second = next(
      (
        lead for lead in usable[1:]
        if lead["dRel"] - usable[0]["dRel"] >= 5.0
      ),
      None,
    )
    return (usable[0],) if second is None else (usable[0], second)

  def _display_leads(
    self,
    scoped_points: tuple[Any, ...],
    extra_identities: Iterable[tuple[str, int]] = (),
  ) -> tuple[
    tuple[dict[str, Any], ...],
    tuple[dict[str, Any], ...],
    tuple[dict[str, Any], ...],
  ]:
    left = []
    center = []
    right = []
    projection_by_identity = {
      (point.source, point.track_id): projection
      for point, _, projection in scoped_points
    }
    visible_identities = {
      (point.source, point.track_id)
      for point in _visible_scoped_motion_points(scoped_points)
    }
    visible_identities.update(extra_identities)
    for point, _, _ in scoped_points:
      if (point.source, point.track_id) not in visible_identities:
        continue
      d_path = projection_by_identity[
        (point.source, point.track_id)
      ].d_path
      lead = self._lead_from_radar_point(point, d_path, 0.03, 0.0)
      if abs(d_path) < 1.8:
        center.append(lead)
      elif d_path > 0.0:
        left.append(lead)
      else:
        right.append(lead)
    for leads in (left, center, right):
      leads.sort(key=lambda lead: lead["dRel"])
    return tuple(left), tuple(center), tuple(right)

  def _lead_from_radar_point(
    self,
    point: RadarPointSnapshot,
    d_path: float,
    model_probability: float,
    score: float,
  ) -> dict[str, Any]:
    lead = lead_from_radar_point(
      point,
      d_path,
      model_probability,
      score,
    )
    lead["aLeadTau"] = self.lead_dynamics.a_lead_tau(point)
    return lead

  def update(
    self,
    time_s: float,
    v_ego: float,
    radar_points: Any,
    model: Any,
    yaw_rate_rad_s: float = 0.0,
    radar_to_model_time_s: float = 0.0,
  ) -> DPathRadarOutput:
    path = _model_path(model)
    if len(path) < 2:
      self.forced_scc_rejected_s = None
      self._forced_scc_previous = None
      self.primary_matcher.reset()
      self.scc_primary_fallback_matcher.reset()
      self.lead_two_tracker.reset()
      self.stationary_shadow_tracker.reset()
      self.stationary_primary_handoff_tracker.reset()
      self.scc_lead_two_tracker.reset()
      self.primary_cut_out_predictor = RadarMotionPredictor(cut_out_only=True)
      self.trajectory_cutout.reset()
      self.lead_dynamics.reset()
      self.trajectory_cutin.reset()
      self._reset_stationary_vision_range_mismatch()
      self._moving_range_last_point = None
      self._moving_range_last_time_s = None
      self._reset_stationary_range_history()
      return DPathRadarOutput(
        None, None, None, None, (), (), (), (), (), (), None,
      )

    points = self._points_at_model_time(
      radar_points,
      v_ego,
      radar_to_model_time_s,
    )
    self.lead_dynamics.update(points, time_s - radar_to_model_time_s)
    front_kinematic_matches = self.front_kinematic_associator.update(points)

    # This is intentionally first: model lead zero identifies leadOne with
    # front-first radar selection before independent CUT-IN prediction.
    primary_match = match_dpath_primary_lead(
      self.primary_matcher,
      model,
      points,
      path,
      time_s=time_s,
      enable_radar_tracks=self.enable_radar_tracks,
      yaw_rate_rad_s=yaw_rate_rad_s,
    )
    vision = self.primary_matcher.vision_fallback
    if self.enable_radar_tracks in (-1, 0):
      # SCC-only modes use the OEM-selected longitudinal object. Its lateral
      # field may be fixed at zero or unreliable, so it cannot gate selection.
      primary_match = unconditional_scc_match(points)
      self._reset_stationary_vision_range_mismatch()
      self._moving_range_last_point = None
      self._moving_range_last_time_s = None
      self._reset_stationary_range_history()
    elif self._reject_farther_radar_match(
      primary_match, vision, path, time_s,
    ):
      # A farther permissive match must not hide a strongly visible nearer car.
      primary_match = None
    if primary_match is None and self.enable_radar_tracks == 3:
      # Mode 3 tries front-radar/vision first, then SCC unless physical lateral
      # evidence identifies an adjacent car. Vision remains the final fallback.
      primary_match = unconditional_scc_match(points)
      if primary_match is not None and self._reject_forced_scc(primary_match.point, points, path, vision, model, time_s):
        primary_match = None
      elif primary_match is None:
        self.forced_scc_rejected_s = None
        self._forced_scc_previous = None
    else:
      self.forced_scc_rejected_s = None
      self._forced_scc_previous = None
    if primary_match is not None:
      self.scc_primary_fallback_matcher.reset()
    elif self.enable_radar_tracks == 2:
      # Some Mando radars temporarily omit a close in-lane lead while the OEM
      # SCC stream and vision still agree on it. Fill only a missing L1: using a
      # separate matcher prevents SCC from replacing an existing front lead,
      # and an empty stationary set forbids uncorroborated radar-only promotion.
      primary_match = self.scc_primary_fallback_matcher.match(
        model,
        tuple(
          point for point in select_primary_radar_points(points, 2)
          if point.source == "scc"
        ),
        path,
        time_s=time_s,
        stationary_points=(),
        prefer_corner_stationary=False,
        prefer_primary_stationary=True,
        yaw_rate_rad_s=yaw_rate_rad_s,
        allowed_output_sources=frozenset(("scc",)),
      )
    else:
      self.scc_primary_fallback_matcher.reset()
    lead_one = None
    if primary_match is not None:
      lead_one = self._lead_from_radar_point(
        primary_match.point,
        primary_match.d_path,
        primary_match.probability,
        primary_match.score,
      )
    else:
      if (
        vision is not None
        and (
          vision_only_lead_allowed(self.enable_radar_tracks)
          or _central_vision_fallback_allowed(vision, path)
        )
      ):
        lead_one = lead_from_vision(
          vision,
          path,
          v_ego,
          model_v_ego=_model_ego_speed(model, v_ego),
        )
    cutout_point = primary_match.point if primary_match is not None and self.enable_radar_tracks > 0 else None
    paired_corners = tuple(
      point for point in points
      if cutout_point is not None and point.source.startswith("corner")
      and (front := front_kinematic_matches.get((point.source, point.track_id))) is not None
      and front.track_id == cutout_point.track_id
      and abs(point.d_rel - cutout_point.d_rel) <= 1.5
      and abs(point.v_rel - cutout_point.v_rel) <= 2.0
    )
    cutout_lateral = min(paired_corners, key=lambda point: abs(point.d_rel - cutout_point.d_rel), default=cutout_point)
    cutout = self.trajectory_cutout.update(time_s, cutout_point, cutout_lateral, vision, path, v_ego, yaw_rate_rad_s)
    if lead_one is not None:
      lead_one["cutOutTime"] = cutout.time_s
      lead_one["cutOutConfidence"] = cutout.confidence
    motion_points = self._select_motion_points(points)
    if self.motion_sensor == "corner":
      # A corner radar can temporarily miss the nearby body that camera and
      # front radar both track. Keep unmatched front points as a vision-only
      # fallback; matched front points stay represented by their corner track.
      matched_front_identities = {
        (point.source, point.track_id)
        for point in front_kinematic_matches.values()
      }
      motion_points += tuple(
        point for point in points
        if (
          point.source == "frontRadar"
          and abs(point.v_rel) <= 5.0
          and (point.source, point.track_id) not in matched_front_identities
        )
      )
    scoped_motion_points = _scoped_motion_points(motion_points, path)
    estimates = self.trajectory_cutin.update(
      time_s,
      v_ego,
      motion_points,
      path,
      model,
      yaw_rate_rad_s=yaw_rate_rad_s,
      vision_required_front=self.motion_sensor == "corner",
      primary_lead=lead_one,
      cross_sensor_matches=front_kinematic_matches,
    )
    estimate_identities = {
      (estimate.point.source, estimate.point.track_id)
      for estimate in estimates
    }
    leads_left, leads_center, leads_right = self._display_leads(
      scoped_motion_points,
      estimate_identities,
    )

    active_identity = self.lead_two_tracker.active_identity
    candidates: list[DPathLeadCandidate] = []
    confirmed_cutin_leads: list[dict[str, Any]] = []
    risk_leads: list[dict[str, Any]] = []
    self._same_row_suppressed_until = {
      identity: until_s
      for identity, until_s in self._same_row_suppressed_until.items()
      if time_s <= until_s
    }
    for estimate in estimates:
      point = estimate.point
      lead_point = prefer_front_radar_kinematics(
        point, points, front_kinematic_matches,
      )
      d_path = (
        project_to_model_path(path, lead_point.d_rel, lead_point.y_rel).d_path
        if lead_point is not point else estimate.d_path
      )
      lead = self._lead_from_radar_point(
        lead_point, d_path, 0.03, estimate.confidence,
      )
      candidate_source = (
        lead_point.kinematics_source
        if estimate.cross_sensor_supported
        and lead_point.kinematics_source is not None
        else point.source
      )
      candidate_track_id = (
        lead_point.kinematics_track_id
        if estimate.cross_sensor_supported
        and lead_point.kinematics_track_id is not None
        else point.track_id
      )
      candidate_continuity_id = (
        candidate_track_id
        if estimate.cross_sensor_supported else estimate.continuity_id
      )
      candidate_lead = lead
      identity = (
        candidate_source, candidate_track_id, candidate_continuity_id,
      )
      same_primary_row_without_vision = (
        estimate.cross_sensor_supported
        and not estimate.vision_supported
        and lead_one is not None
        and lead_one.get("status")
        and float(candidate_lead.get("dRel", 0.0)) > 8.0
        and abs(
          float(candidate_lead.get("dRel", 0.0))
          - float(lead_one.get("dRel", 0.0))
        ) <= 3.0
      )
      if same_primary_row_without_vision:
        self._same_row_suppressed_until[identity] = time_s + 0.75
      same_row_suppressed = (
        not estimate.vision_supported
        and time_s <= self._same_row_suppressed_until.get(identity, -math.inf)
      )
      if (
        lead_duplicates_primary(candidate_lead, lead_one)
        or same_row_suppressed
      ):
        if active_identity == identity:
          self.lead_two_tracker.reset()
        continue
      can_compete = cutin_can_compete_with_primary(
        candidate_lead,
        lead_one,
        projected_path_entry=(
          estimate.time_to_overlap_s is not None
          or estimate.confirmed_cutin
        ),
        entry_horizon_s=estimate.time_to_overlap_s,
      )
      detected_cutin = (
        self.cut_in_sensitivity > 0
        and estimate.confirmed_cutin
        and can_compete
      )
      confirmed_cutin = detected_cutin and estimate.control_eligible
      if detected_cutin:
        confirmed_cutin_leads.append(lead)
      if self.cut_in_sensitivity > 0 and estimate.predecel_risk and can_compete:
        risk_leads.append(lead)
      # A withdrawn entry or side pass cannot retain a full lead role. Keep the independently
      # gated, bounded low-speed pre-deceleration path above available when
      # substantial inward motion still warrants a precaution.
      if (
        estimate.entry_withdrawn or estimate.passing_before_overlap
        or estimate.parallel_drift or estimate.rear_pass or estimate.stationary_pair_alias
      ):
        if active_identity == identity:
          self.lead_two_tracker.reset()
        continue
      candidates.append(DPathLeadCandidate(
        lead=candidate_lead,
        source=candidate_source,
        track_id=candidate_track_id,
        continuity_id=candidate_continuity_id,
        retainable=(
          estimate.current_path
          or estimate.d_path * estimate.d_path_rate <= 0.0
        ),
        confirmed_cutin=confirmed_cutin,
        allow_low_speed=estimate.cross_sensor_supported,
      ))

    lead_cutin_risk = min(
      risk_leads,
      key=lambda lead: (
        float(lead.get("dRel", math.inf)),
        -float(lead.get("score", 0.0)),
      ),
      default=None,
    )
    if self.motion_sensor == "front":
      front_motion_points = motion_points
      front_scoped_motion_points = scoped_motion_points
    else:
      front_motion_points = tuple(
        point for point in points if point.source == "frontRadar"
      )
      front_scoped_motion_points = _scoped_motion_points(
        front_motion_points, path,
      )
    primary_track_id = (
      int(lead_one.get("radarTrackId", -1))
      if lead_one is not None and lead_one.get("radar")
      else -1
    )
    primary_cut_out_identities = frozenset(
      (point.source, point.track_id)
      for point in front_motion_points
      if point.track_id == primary_track_id
    )
    primary_cut_out_predictions = self.primary_cut_out_predictor.update(
      time_s,
      front_motion_points,
      path,
      v_ego,
      yaw_rate_rad_s,
      scoped_points=front_scoped_motion_points,
      prediction_identities=primary_cut_out_identities,
    )
    primary_cut_out_probability = max((
      float(prediction.cut_out_probability)
      for prediction in primary_cut_out_predictions.values()
      if prediction.track_id == primary_track_id
    ), default=0.0)
    stationary_primary_candidates = []
    primary_vision = self.primary_matcher.vision_fallback
    for point, _, projection in scoped_motion_points:
      if not _is_corner(point):
        continue
      model_probability = stationary_vision_support_probability(
        primary_vision, point,
      )
      lead = self._lead_from_radar_point(
        point, projection.d_path, model_probability, 0.0,
      )
      stationary_primary_candidates.append(DPathLeadCandidate(
        lead=lead,
        source=point.source,
        track_id=point.track_id,
        continuity_id=0,
        retainable=True,
        confirmed_cutin=False,
      ))
    stationary_primary_handoff = (
      self.stationary_primary_handoff_tracker.update(
        time_s,
        lead_one,
        stationary_primary_candidates,
        active_identity,
      )
    )
    if (
      stationary_primary_handoff is not None
      and not any(
        candidate.identity == stationary_primary_handoff.identity
        for candidate in candidates
      )
    ):
      candidates.append(stationary_primary_handoff)
    stationary_shadow_inputs = []
    for point, _, projection in front_scoped_motion_points:
      identity = (point.source, point.track_id, 0)
      retained_stationary_shadow = active_identity == identity
      corner_supported = stationary_shadow_corner_supported(
        point, points, path,
      )
      if (
        point.radar_track_state < 2
        or not (corner_supported or retained_stationary_shadow)
      ):
        continue
      lead = self._lead_from_radar_point(
        point, projection.d_path, 0.03, primary_cut_out_probability,
      )
      candidate = DPathLeadCandidate(
        lead=lead,
        source=point.source,
        track_id=point.track_id,
        continuity_id=0,
        retainable=True,
        confirmed_cutin=False,
      )
      if corner_supported:
        stationary_shadow_inputs.append(candidate)
      if (
        retained_stationary_shadow
        and point.track_id != primary_track_id
      ):
        candidates.append(candidate)
    stationary_shadow = self.stationary_shadow_tracker.update(
      time_s,
      lead_one,
      primary_cut_out_probability,
      stationary_shadow_inputs,
    )
    if (
      stationary_shadow is not None
      and stationary_shadow.confirmed_stationary_shadow
      and stationary_shadow.track_id != primary_track_id
      and not any(
        candidate.identity == stationary_shadow.identity
        for candidate in candidates
      )
    ):
      candidates.append(stationary_shadow)
    if (
      active_identity is not None
      and not any(candidate.identity == active_identity for candidate in candidates)
    ):
      source, track_id, continuity_id = active_identity
      point = next((
        value for value in points
        if value.source == source and value.track_id == track_id
      ), None)
      if point is not None:
        lead_point = prefer_front_radar_kinematics(
          point, points, front_kinematic_matches,
        )
        d_path = project_to_model_path(
          path, lead_point.d_rel, lead_point.y_rel,
        ).d_path
        lead = self._lead_from_radar_point(
          lead_point, d_path, 0.03, 0.0,
        )
        if not lead_duplicates_primary(lead, lead_one):
          # A brief vision-range handoff can make the retained auxiliary
          # object leadOne for one frame. Hide the duplicate output without
          # discarding its physical continuity; if the prior leadOne returns,
          # the still-continuous auxiliary track can resume immediately.
          candidates.append(DPathLeadCandidate(
            lead=lead,
            source=source,
            track_id=track_id,
            continuity_id=continuity_id,
            retainable=True,
            confirmed_cutin=False,
          ))
    selection = self.lead_two_tracker.update(
      time_s,
      lead_one,
      candidates,
      v_ego,
    )
    scc_point = min(
      (
        point for point in points
        if self.enable_radar_tracks >= 2
        and point.measured and point.source == "scc"
        and 0.8 < point.d_rel <= SCC_LEAD_TWO_MAX_DREL_M
        and point.v_lead < SCC_LEAD_TWO_MAX_VLEAD_MPS
      ),
      key=lambda point: point.d_rel,
      default=None,
    )
    physical_support = (
      _scc_physical_support(scc_point, points, path)
      if scc_point is not None else None
    )
    scc_point = self.scc_lead_two_tracker.update(
      time_s, scc_point,
      independently_supported=(
        scc_point is not None
        and _scc_lead_two_independently_supported(
          scc_point, physical_support, points, path,
          vision_lead_from_model(model), lead_one,
        )
      ),
    )
    scc_lead_two = None
    if scc_point is not None:
      lead_point = physical_support or scc_point
      scc_lead_two = self._lead_from_radar_point(
        lead_point,
        project_to_model_path(
          path, lead_point.d_rel, lead_point.y_rel,
        ).d_path,
        0.03,
        1.0 if physical_support is not None else 0.5,
      )
      if not _scc_lead_two_can_compete(scc_lead_two, lead_one):
        scc_lead_two = None
    lead_two = selection.lead_two
    if (
      scc_lead_two is not None
      and (
        lead_two is None
        or float(scc_lead_two["dRel"]) < float(lead_two["dRel"])
      )
    ):
      lead_two = scc_lead_two
    return DPathRadarOutput(
      lead_one=lead_one,
      lead_two=lead_two,
      lead_left=self._pick_side(leads_left),
      lead_right=self._pick_side(leads_right),
      leads_left=leads_left,
      leads_center=leads_center,
      leads_right=leads_right,
      leads_cutin=tuple(sorted(
        confirmed_cutin_leads,
        key=lambda lead: float(lead["dRel"]),
      )),
      leads_left2=self._pick_two(leads_left),
      leads_right2=self._pick_two(leads_right),
      lead_cutin_risk=lead_cutin_risk,
    )
